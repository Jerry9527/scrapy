# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
import json
import time
import execjs
# import urlparse
from zhihu.items import ZhihuItem
import re

class ZhihuSpider(CrawlSpider):
    name = 'zhihu'
    allowed_domains = ['zhihu.com']
    start_urls = ['https://www.zhihu.com/']

    phone = '+8618549834917'  # 手机号
    password = '946265wy'  # 密码
    client_id = 'c3cef7c66a1843f8b3a9e6a1e3160e20'
    headers = {
        'authorization': 'oauth ' + client_id,
        'Host': 'www.zhihu.com',
        'Origin': 'https://www.zhihu.com',
        'Referer': 'https://www.zhihu.com/signup?next=%2F',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
    }

    # 因为需要先登录再爬取，因此需要重写start_requests
    def start_requests(self):
        yield scrapy.Request('https://www.zhihu.com/api/v3/oauth/captcha?lang=cn',headers=self.headers,callback=self.login,dont_filter=True)

    def login(self, response):
        captcha_info = json.loads(response.text)
        if captcha_info['show_captcha']:  # 出现验证码
            print('出现验证码')
            print(captcha_info)
            headers = {
                'authorization': 'oauth ' + self.client_id,
                'Host': 'www.zhihu.com',
                'Origin': 'https://www.zhihu.com',
                'Referer': 'https://www.zhihu.com/signup?next=%2F',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
                'Accept': 'application/json,text/plain,*/*',
                'Accept-Language':'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
                'Accept-Encoding':'gzip, deflate, br',
                'x-udid':'ACBvyAh_dA2PTjFQf1ctAKqVu8DfB5ZosWU=',
                'x-xsrftoken':'95fe0f33-cf9a-4652-8440-926c75b4731a',
            }
            yield scrapy.Request('https://www.zhihu.com/api/v3/oauth/captcha?lang=cn',headers=headers,callback=self.login,dont_filter=True)
        else:
            print(response.text)
            loginUrl = 'https://www.zhihu.com/api/v3/oauth/sign_in'
            timestamp = int(time.time() * 1000)
            fp = open(r'zhihu/spiders/zhihu.js')
            js = fp.read()
            fp.close()
            ctx = execjs.compile(js)
            signature = ctx.call('getSignature', timestamp)
            params = {
                'client_id': self.client_id,
                'grant_type': 'password',
                'timestamp': str(timestamp),
                'source': 'com.zhihu.web',
                'signature': signature,
                'username': str(self.phone),
                'password': str(self.password),
                'captcha': '',
                'lang': 'cn',
                'ref_source': 'homepage',
                'utm_source': ''
            }

            yield scrapy.FormRequest(url=loginUrl, headers=self.headers, formdata=params, method='POST',
                                     callback=self.check_login)

    def check_login(self, response):
        # 验证服务器返回是否成功。
        HomeUrl = 'https://www.zhihu.com'
        headers = {
            'Host': 'www.zhihu.com',
            'Referer': 'https://www.zhihu.com/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36'
        }
        print("登录成功")
        # print(response.url)
        # print(response.text)
        yield scrapy.Request(url=r'https://www.zhihu.com',headers=headers,dont_filter=True,callback=self.parse_zhihu)

    def parse_zhihu(self,response):
        all_urls = response.xpath('//a/@href').extract()
        all_urls = [response.urljoin(url) for url in all_urls]
        all_urls = filter(lambda x:True if x.startswith('https') else False,all_urls)
        for url in all_urls:
            match_obj = re.match('(.*zhihu.com/question/(\d+))(/|$).*',url)
            if match_obj:
                request_url = match_obj.group(1)
                yield scrapy.Request(request_url,headers=self.headers,callback=self.parse_question)
            else:
                yield scrapy.Request(url,headers=self.headers,callback=self.parse_zhihu)

    def parse_question(self,response):
        # print(response.text)
        papers = response.xpath(r'//div[@class="QuestionHeader-main"]')
        for paper in papers:
            title = paper.xpath('.//h1[@class="QuestionHeader-title"]/text()').extract()
            if title:
                title = title[0]
            else:
                title = ''
            print('---------------------')
            print('title:',title)
            print('---------------------')
            item = ZhihuItem(title=title)
            yield item