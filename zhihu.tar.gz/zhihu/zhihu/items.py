# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class ZhihuItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    '''
    用户信息
        name:用户昵称
        addr:住址
        zone:所在领域
        comp:公司
        job:职位
        educ:教育
        focus_nums:关注的人数
        focused_nums:被关注的人数
    人际关系
        focus_id:关注人的id
        focused_id:被关注人的id
    '''
    name = scrapy.Field()
    addr = scrapy.Field()
    zone = scrapy.Field()
    comp = scrapy.Field()
    job = scrapy.Field()
    educ = scrapy.Field()
    focus_nums = scrapy.Field()
    focused_nums = scrapy.Field()
    focus_id = scrapy.Field()
    focused_id = scrapy.Field()

#用户信息的Item
class UserInfoItem(scrapy.Item):
    #用户id
    user_id = scrapy.Field()
    #用户头像
    user_img_url = scrapy.Field()
    #用户姓名
    name = scrapy.Field()
    #居住地
    location = scrapy.Field()
    #技术领域
    business = scrapy.Field()
    #性别
    gender = scrapy.Field()
    #公司
    employment = scrapy.Field()
    #职位
    position = scrapy.Field()
    #教育经历
    education = scrapy.Field()
    #我关注的人数
    followees_num = scrapy.Field()
    #关注我的人数
    followers_num = scrapy.Field()

class RelationItem(scrapy.Item):
    #用户id
    user_id = scrapy.Field()
    #relation类别
    relation_type = scrapy.Field()
    #有关系的id
    relations_id = scrapy.Field()