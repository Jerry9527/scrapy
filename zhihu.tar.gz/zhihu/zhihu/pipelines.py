# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymongo

class ZhihuPipeline(object):
    def process_item(self, item, spider):
        return item

class MongoDBPipeline(object):

    def __init__(self, mongo_uri, mongo_db, mongo_col, mongo_port):
        self.mongo_uri = mongo_uri
        self.mongo_db = mongo_db
        self.mongo_col = mongo_col
        self.mongo_port = mongo_port

    @classmethod
    def from_crawler(cls, crawler):
        mongo_uri = crawler.settings.get('MONGODB_HOST')
        mongo_db = crawler.settings.get('MONGODB_DBNAME', 'zhihu')
        mongo_col = crawler.settings.get('MONGODB_CNAME', 'title')
        mongo_port = crawler.settings.get('MONGODB_PORT', 27017)
        return cls(mongo_uri=mongo_uri, mongo_db=mongo_db, mongo_col=mongo_col, mongo_port=mongo_port)

    def open_spider(self, spider):
        self.client = pymongo.MongoClient(host=self.mongo_uri,port=self.mongo_port)
        self.db = self.client[self.mongo_db]
        self.col = self.db[self.mongo_col]

    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        self.col.insert(dict(item))
        return item