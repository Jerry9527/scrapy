# encoding=utf-8
from scrapy import cmdline

if __name__ == '__main__':
    cmdline.execute('scrapy crawl shengangtong -o 1.json -s FEED_EXPORT_ENCODING=utf-8'.split())