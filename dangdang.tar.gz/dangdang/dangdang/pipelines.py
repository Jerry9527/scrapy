# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

from scrapy.conf import settings
import pymongo

#MongoDB集群
class MongoDBPipeline(object):

    def __init__(self, mongo_uri, mongo_replicaset, mongo_db, mongo_col):
        self.mongo_uri = mongo_uri
        self.mongo_replicaset = mongo_replicaset
        self.mongo_db = mongo_db
        self.mongo_col = mongo_col

    @classmethod
    def from_crawler(cls, crawler):
        mongo_uri = crawler.settings.get('MONGODB_HOST')
        mongo_replicaset = crawler.settings.get('MONGODB_REPLICASET')
        mongo_db = crawler.settings.get('MONGODB_DBNAME', 'dangdang')
        mongo_col = crawler.settings.get('MONGODB_CNAME', 'book')
        return cls(mongo_uri=mongo_uri, mongo_replicaset=mongo_replicaset, mongo_db=mongo_db, mongo_col=mongo_col)

    def open_spider(self, spider):
        self.client = pymongo.MongoClient(host=self.mongo_uri, replicaset=self.mongo_replicaset)
        self.db = self.client[self.mongo_db]
        self.col = self.db[self.mongo_col]

    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        self.col.insert(dict(item))
        return item
