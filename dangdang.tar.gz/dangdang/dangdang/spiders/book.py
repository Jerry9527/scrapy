# -*- coding: utf-8 -*-
import scrapy
from dangdang.items import BookItem


class BookSpider(scrapy.Spider):
    name = 'book'
    allowed_domains = ['dangdang.com']
    start_urls = ['http://www.dangdang.com/']
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36"}

    def start_requests(self):
        url = "http://search.dangdang.com/?key=" + "python" + "&act=input"
        yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        papers = response.xpath('//ul[@class="bigimg"]/li')
        for paper in papers:
            book_name = paper.xpath('p[@class="name"]/a/@title').extract()
            book_url = paper.xpath('p[@class="name"]/a/@href').extract()
            book_price = paper.xpath('p[@class="price"]/span[@class="search_now_price"]/text()').re(r'^¥(.*)')
            book_author = paper.xpath('p[@class="search_book_author"]/span[1]/a/@title').extract()
            book_date = paper.xpath('p[@class="search_book_author"]/span[2]/text()').re(r'/(.+)')
            book_press = paper.xpath('p[@class="search_book_author"]/span[3]/a/@title').extract()
            book_remarks = paper.xpath('p[@class="search_star_line"]/a[@class="search_comment_num"]/text()').re(
                r'(\d+)条评论')
            book_desp = paper.xpath('p[@class="detail"]/text()').extract()
            if book_name:
                book_name = book_name[0]
            if book_url:
                book_url = book_url[0]
            if book_price:
                book_price = book_price[0]
            if book_author:
                book_author = book_author[0]
            if book_date:
                book_date = book_date[0]
            if book_press:
                book_press = book_press[0]
            if book_remarks:
                book_remarks = book_remarks[0]
            if book_desp:
                book_desp = book_desp[0]

            item = BookItem(book_name=book_name, book_url=book_url, book_price=book_price, book_author=book_author,
                            book_date=book_date, book_press=book_press, book_remarks=book_remarks, book_desp=book_desp)
            yield item

        next_page = response.xpath('//div[@class="paging"]/ul/li[@class="next"]/a/@href').extract()
        if next_page:
            yield scrapy.Request(url="http://search.dangdang.com" + next_page[0], callback=self.parse,
                                 headers=self.headers)
