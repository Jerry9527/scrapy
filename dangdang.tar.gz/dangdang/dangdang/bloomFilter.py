# -*- coding: utf-8 -*-

from scrapy.dupefilter import RFPDupeFilter
from w3lib.url import canonicalize_url
from pybloom_live  import ScalableBloomFilter


class URLBloomFilter(RFPDupeFilter):
    def __init__(self, path=None):
        self.urls_sbf = ScalableBloomFilter(mode=ScalableBloomFilter.SMALL_SET_GROWTH)
        RFPDupeFilter.__init__(self, path)

    def request_seen(self,request):
        fp = hashlib.sha1()
        fp.update(canonicalize_url(request.url))
        url_sha1 = fp.hexdigest()
        if url_sha1 in self.urls_sbf:
            return True
        else:
            self.urls_sbf.add(url_sha1)
