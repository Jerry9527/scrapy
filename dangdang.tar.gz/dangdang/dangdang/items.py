# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class BookItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()

    '''
    BOOK
    book_name:书名
    book_url:书的链接
    book_price:书价
    book_author:书的作者
    book_date:书的出版日期
    book_press:书的出版商
    book_desp:书的介绍
    book_remarks:书的评论
    '''

    book_name = scrapy.Field()
    book_url = scrapy.Field()
    book_price = scrapy.Field()
    book_author = scrapy.Field()
    book_date = scrapy.Field()
    book_press = scrapy.Field()
    book_desp = scrapy.Field()
    book_remarks = scrapy.Field()