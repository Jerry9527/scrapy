# -*- coding: utf-8 -*-
import scrapy
from freebuf.items import ArticleItem


class ArticleSpider(scrapy.Spider):
    name = 'article'
    allowed_domains = ['freebuf.com']
    start_urls = ['http://freebuf.com/']
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36'}

    def start_requests(self):
        url = 'http://www.freebuf.com/articles'
        yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        papers = response.xpath('//div[@class="news-detial"]/div[@class="news_inner news-list"]')
        for paper in papers:
            article_title = paper.xpath('div[@class="news-info"]/dl/dt/a[@class="article-title"]/@title').extract()
            article_url = paper.xpath('div[@class="news-info"]/dl/dt/a[@class="article-title"]/@href').extract()
            article_author = paper.xpath('div[@class="news-info"]/dl/dd/span[@class="name"]/a/text()').extract()
            article_date = paper.xpath('div[@class="news-info"]/dl/dd/span[@class="time"]/text()').extract()
            article_desp = paper.xpath('div[@class="news-info"]/dl/dd[@class="text"]/text()').extract()
            article_type = []
            article_types = paper.xpath(
                'div[@class="news-info"]/div[@class="news_bot"]/span[@class="tags"]/a')
            for type in article_types:
                content = type.xpath('text()').extract()[0]
                article_type.append(content)
            article_person_nums = paper.xpath(
                'div[@class="news-info"]/div[@class="news_bot"]/span[@class="look"]/strong[1]/text()').extract()
            article_ufo_nums = paper.xpath(
                'div[@class="news-info"]/div[@class="news_bot"]/span[@class="look"]/strong[2]/text()').extract()

            if article_title:
                article_title = article_title[0]
            if article_url:
                article_url = article_url[0]
            if article_author:
                article_author = article_author[0]
            if article_date:
                article_date = article_date[0]
            if article_desp:
                article_desp = article_desp[0]
            # if article_type:
            #     article_type = article_type[0]
            if article_person_nums:
                article_person_nums = article_person_nums[0]
            if article_ufo_nums:
                article_ufo_nums = article_ufo_nums[0]
            item = ArticleItem(article_title=article_title, article_url=article_url, article_author=article_author,
                               article_date=article_date, article_desp=article_desp, article_type=article_type,
                               article_person_nums=article_person_nums, article_ufo_nums=article_ufo_nums,
                               )
            request = scrapy.Request(url=article_url, callback=self.parseArticleContent, headers=self.headers)
            request.meta['item'] = item
            yield request
            # yield item
        next_page = response.xpath('//div[@class="news-more"]/a/@href').extract()
        if next_page:
            yield scrapy.Request(url=next_page[0], callback=self.parse, headers=self.headers)

    # 文章的具体内容
    def parseArticleContent(self, response):
        item = response.meta['item']
        article_content = response.xpath('//div[@id="contenttxt"]').extract()[0]
        item['article_content'] = article_content
        yield item
