# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


import pymongo
from scrapy.conf import settings

class MongoDBPipeline(object):

    def __init__(self):
        port = settings['MONGODB_PORT']
        host = settings['MONGODB_HOST']
        db_name = settings['MONGODB_DBNAME']
        client = pymongo.MongoClient(port=port,host=host)
        db = client[db_name]
        self.collection = db[settings['MONGODB_CNAME']]

    def process_item(self, item, spider):
        self.collection.insert(dict(item))
        return item
