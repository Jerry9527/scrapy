# -*- coding: utf-8 -*-
import scrapy
from github.items import GithubItem


class CodesSpider(scrapy.Spider):
    name = 'codes'
    allowed_domains = ['github.com']
    start_urls = ['https://github.com']
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36",
        "Referer": "https://github.com/",
    }

    def start_requests(self):
        yield scrapy.Request(url="https://github.com/login", callback=self.parseLogin,
                             meta={"cookiejar": 1})  # cookiejar用于传递cookie

    # def parse(self, response):
    #     pass

    # 登录界面
    def parseLogin(self, response):
        # authenticity_token:在response中能获取到
        authenticity_token = response.xpath(
            './/div[@class="auth-form px-3"]/form/div[1]/input[@name="authenticity_token"]/@value').extract()
        if authenticity_token:
            authenticity_token = authenticity_token[0]
        form_data = {
            # 'commit':'Sign in',
            'utf8': '✓',
            'authenticity_token': authenticity_token,
            'login': 'Jerry9527',
            'password': '946265wy',
        }

        yield scrapy.FormRequest.from_response(response, url="https://github.com/session", formdata=form_data,
                                               headers=self.headers, meta={'cookiejar': response.meta['cookiejar']},
                                               callback=self.parseAfterLogin, dont_filter=True)

    # 登录之后
    def parseAfterLogin(self, response):
        url = "https://github.com/georgeOsdDev"
        request = scrapy.Request(url=url, callback=self.parse, headers=self.headers,
                                 meta={'cookiejar': response.meta['cookiejar'],'url':url})
        yield request

    # 收集单个用户的信息
    def parse(self, response):
        user_name = response.xpath(
            './/div[@class="vcard-names-container py-3 js-sticky js-user-profile-sticky-fields "]/h1/span[1]/text()').extract()
        user_nickname = response.xpath(
            './/div[@class="vcard-names-container py-3 js-sticky js-user-profile-sticky-fields "]/h1/span[2]/text()').extract()
        user_profile = response.xpath('//div[@class="p-note user-profile-bio"]/div/text()').extract()
        groups = response.xpath(
            '//ul[@class="vcard-details border-top border-gray-light py-3"]/li[@aria-label="Organization"]/span[@class="p-org"]/div/a')
        user_groups = []
        for group in groups:
            x = group.xpath('text()').extract()
            if x:
                x = x[0]
            user_groups.append(x)
        user_location = response.xpath(
            '//ul[@class="vcard-details border-top border-gray-light py-3"]/li[@aria-label="Home location"]/span[@class="p-label"]/text()').extract()
        user_blog = response.xpath(
            '//ul[@class="vcard-details border-top border-gray-light py-3"]/li[@aria-label="Blog or website"]/a[@class="u-url"]/text()').extract()
        orgs = response.xpath('//div[@class="border-top py-3 clearfix"]/a[@class="tooltipped tooltipped-n avatar-group-item"]')
        user_orgs = []
        for org in orgs:
            x = org.xpath('img/@src').extract()
            if x:
                x = x[0]
            user_orgs.append(x)
        if user_name:
            user_name = user_name[0]
        if user_nickname:
            user_nickname = user_nickname[0]
        if user_profile:
            user_profile = user_profile[0]
        if user_location:
            user_location = user_location[0]
        if user_blog:
            user_blog = user_blog[0]

        item = GithubItem(user_name=user_name, user_nickname=user_nickname, user_profile=user_profile,
                          user_groups=user_groups, user_location=user_location, user_blog=user_blog,
                          user_orgs=user_orgs,user_following=[])
        url = response.meta['url'] + r"?tab=following"
        request = scrapy.Request(url=url, callback=self.get_all_following, headers=self.headers,
                                 meta={'cookiejar': response.meta['cookiejar'], 'item': item})
        yield request

    # 收集关注该用户的人的链接
    def get_all_following(self, response):
        item = response.meta['item']
        papers = response.xpath(
            '//div[@class="col-9 float-left pl-2"]/div[@class="position-relative"]/div[@class="d-table col-12 width-full py-4 border-bottom border-gray-light"]/div[@class="d-table-cell col-9 v-align-top pr-3"]')
        for paper in papers:
            following = paper.xpath("a/@href").extract()
            if following:
                item['user_following'].append(self.start_urls[0]+following[0])
        next_page = response.xpath('//div[@class="pagination"]/a[@rel="nofollow"]').re(ur'<a href="(.+)" rel="nofollow">Next</a>')
        if next_page:
            yield scrapy.Request(url=next_page[0], callback=self.get_all_following, headers=self.headers,
                                 meta={'cookiejar': response.meta['cookiejar'], 'item': item})
        else:
            yield item
            for url in item['user_following']:
                yield scrapy.Request(url=url,callback=self.parse,headers=self.headers,
                                     meta={'cookiejar':response.meta['cookiejar'],'url':url})